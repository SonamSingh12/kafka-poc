package com.poc.kafka;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.poc.kafka.constants.IKafkaConstants;
import com.poc.kafka.consumer.ConsumerCreator;
import com.poc.kafka.producer.ProducerCreator;
import redis.clients.jedis.Jedis; 

public class App implements readFromRedis {
	public static void main(String[] args) {
		//first input is consumer topic name..
		if(args.length >= 2){
			System.out.println("runConsumer called for topic " +args[0]);
		    runConsumer(args[0], args[1]);
		} else {
		    System.out.println("Consume/Produce Topic not found...");
		}
	}

	private static void readFromRedis(Jedis jedis) {
		// Get the stored data and print it 
	      Set<String> list = jedis.keys("*"); 
	      
	      for(String str: list) { 
	         System.out.println("List of stored keys:: "+str); 
	      }
	}
	
	private static String readFromRedisKey(String key) {
	   Jedis jedis = new Jedis("redis"); 
       System.out.println("Server is running: "+jedis.ping());
		// Get the stored data and print it 
	   String strVal = jedis.get(key);
	      
	     // for(String str: list) { 
	   System.out.println("value from given key " +strVal);
	   jedis.close();
	   return strVal;
	    //  }
	}

	private static void storeToRedish(Jedis jedis) {
		//store data in redis list 
	      jedis.lpush("tutorial-list", "Redis"); 
	      jedis.lpush("tutorial-list", "Mongodb"); 
	      jedis.lpush("tutorial-list", "Mysql"); 
	      // Get the stored data and print it 
	      List<String> list = jedis.lrange("tutorial-list", 0 ,5); 
	      
	      for(int i = 0; i<list.size(); i++) { 
	         System.out.println("Stored string in redis:: "+list.get(i)); 
	      }
	}

	static void runConsumer(String ConsumeTopic, String ProduceTopic) {
		Consumer<Long, String> consumer = ConsumerCreator.createConsumer(ConsumeTopic);

		int noMessageToFetch = 0;

		while (true) {
			final ConsumerRecords<Long, String> consumerRecords = consumer.poll(1000);
			if (consumerRecords.count() == 0) {
				noMessageToFetch++;
				if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
					break;
				else
					continue;
			}

			consumerRecords.forEach(record -> {
				System.out.println("Record Key " + record.key());
				List<String> items = Arrays.asList(record.value().split(","));
				if(null != items.get(92) && items.get(92) != ""){
					System.out.println("Record value program id " + items.get(92));
					String sVal = readFromRedisKey(items.get(92));
					String sValues = sVal.replaceAll("\\|", ",");   
					runProducer(ProduceTopic, sValues);
				}
				else{
					System.out.println("Record value program is empty");
					runProducer(ProduceTopic, "N/A,N/A,N/A,N/A,N/A");
				}
				System.out.println("Record value " + record.value());
				System.out.println("Record partition " + record.partition());
				System.out.println("Record offset " + record.offset());
			});
			consumer.commitAsync();
		}
		consumer.close();
	}

	static void runProducer(String ProduceTopic, String value) {
		Producer<Long, String> producer = ProducerCreator.createProducer();

		//for (int index = 0; index < IKafkaConstants.MESSAGE_COUNT; index++) {
			//final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(IKafkaConstants.TOPIC_NAME,
					//"This is record " + index);
		final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(ProduceTopic,
				value);
			try {
				RecordMetadata metadata = producer.send(record).get();
				System.out.println("Record sent to partition " + metadata.partition()
						+ " with offset " + metadata.offset());
			} catch (ExecutionException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			} catch (InterruptedException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			}
		//}
	}
}
