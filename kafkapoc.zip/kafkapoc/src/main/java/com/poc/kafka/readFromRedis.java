package com.poc.kafka;

public interface readFromRedis {

}